<?php


namespace ACFCustomDatabaseTables\DB;


class DynamicSubTable extends DynamicTableBase {


	/**
	 * Returns the table type
	 *
	 * @return string
	 */
	function type() {
		return self::TYPE_SUB;
	}


	// todo


}